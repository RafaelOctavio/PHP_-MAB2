<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 

    $pasta = "ADM/IMG/";
    
    $arq = glob("$pasta{*.jpg,*.png,*.jpeg,*.gif}", GLOB_BRACE);

    foreach ( $arq as $pos){
        echo "<img src='".$pos."'/>";
    }
    ?>
</body>
</html>